# No custom shrinking rules are needed for this small app.
