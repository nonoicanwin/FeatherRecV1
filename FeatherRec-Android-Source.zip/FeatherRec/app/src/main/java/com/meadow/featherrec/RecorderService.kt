package com.meadow.featherrec

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class RecorderService : Service() {
    private var recorder: MediaRecorder? = null
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var display: VirtualDisplay? = null
    private var outputUri: Uri? = null
    private var outputFile: ParcelFileDescriptor? = null
    private var isRecording = false
    private var isStopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopRecording()
            return START_NOT_STICKY
        }
        if (isRecording) return START_NOT_STICKY

        createNotificationChannel()
        startForeground(
            NOTIFICATION_ID,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val resultData = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        val use720p = intent?.getBooleanExtra(EXTRA_720P, true) ?: true
        val useMic = intent?.getBooleanExtra(EXTRA_MIC, false) ?: false

        if (resultCode != Activity.RESULT_OK || resultData == null) {
            publishState(false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
            return START_NOT_STICKY
        }

        try {
            beginRecording(resultCode, resultData, use720p, useMic)
        } catch (failure: Exception) {
            android.util.Log.e(TAG, "Could not start screen recording", failure)
            stopRecording()
        }
        return START_NOT_STICKY
    }

    private fun beginRecording(resultCode: Int, resultData: Intent, use720p: Boolean, useMic: Boolean) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val screenWidth = max(2, metrics.widthPixels)
        val screenHeight = max(2, metrics.heightPixels)
        val outWidth: Int
        val outHeight: Int
        if (use720p) {
            val scale = 720f / min(screenWidth, screenHeight).toFloat()
            outWidth = (screenWidth * scale).toInt().coerceAtLeast(2) and -2
            outHeight = (screenHeight * scale).toInt().coerceAtLeast(2) and -2
        } else {
            outWidth = screenWidth and -2
            outHeight = screenHeight and -2
        }

        outputUri = createOutputUri()
        outputFile = contentResolver.openFileDescriptor(outputUri!!, "w")
            ?: throw IllegalStateException("Could not open output video")

        val mr = MediaRecorder()
        recorder = mr
        if (useMic) mr.setAudioSource(MediaRecorder.AudioSource.MIC)
        mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        mr.setOutputFile(outputFile!!.fileDescriptor)
        mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        mr.setVideoSize(outWidth, outHeight)
        mr.setVideoFrameRate(60)
        mr.setVideoEncodingBitRate(if (use720p) 5_500_000 else 12_000_000)
        if (useMic) {
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioSamplingRate(44_100)
            mr.setAudioEncodingBitRate(96_000)
        }
        mr.prepare()

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, resultData)
            ?: throw IllegalStateException("Screen capture permission was not granted")
        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopRecording()
            }
        }
        projectionCallback = callback
        projection!!.registerCallback(callback, Handler(Looper.getMainLooper()))

        display = projection!!.createVirtualDisplay(
            "FeatherRec-Screen",
            outWidth,
            outHeight,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            mr.surface,
            null,
            null
        ) ?: throw IllegalStateException("Could not create screen display")

        mr.start()
        isRecording = true
        publishState(true)
    }

    private fun createOutputUri(): Uri {
        val fileName = "FeatherRec_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/FeatherRec")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create a video in Movies/FeatherRec")
    }

    private fun stopRecording() {
        if (isStopping) return
        isStopping = true
        val wasRecording = isRecording
        isRecording = false
        var videoIsValid = false

        if (wasRecording) {
            try {
                recorder?.stop()
                videoIsValid = true
            } catch (failure: Exception) {
                android.util.Log.w(TAG, "Recorder stopped before a valid clip was produced", failure)
            }
        }

        try { display?.release() } catch (_: Exception) { }
        display = null
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null

        val currentProjection = projection
        val currentCallback = projectionCallback
        if (currentProjection != null && currentCallback != null) {
            try { currentProjection.unregisterCallback(currentCallback) } catch (_: Exception) { }
        }
        projectionCallback = null
        try { currentProjection?.stop() } catch (_: Exception) { }
        projection = null

        try { outputFile?.close() } catch (_: Exception) { }
        outputFile = null
        outputUri?.let { uri ->
            if (videoIsValid) {
                val values = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                try { contentResolver.update(uri, values, null, null) } catch (_: Exception) { }
            } else {
                try { contentResolver.delete(uri, null, null) } catch (_: Exception) { }
            }
        }
        outputUri = null
        publishState(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        isStopping = false
    }

    private fun publishState(running: Boolean) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(PREF_RECORDING, running).apply()
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra(EXTRA_RUNNING, running))
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Screen recording", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Shows when FeatherRec is recording your screen"
                }
            )
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 10, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 11, Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("FeatherRec is ready")
            .setContentText("Screen capture · 60 FPS target")
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, "STOP", stop)
            .build()
    }

    override fun onDestroy() {
        if (isRecording && !isStopping) stopRecording()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.meadow.featherrec.action.STOP"
        const val ACTION_STATE = "com.meadow.featherrec.action.STATE"
        const val EXTRA_RUNNING = "running"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_720P = "use_720p"
        const val EXTRA_MIC = "use_mic"
        const val PREFS = "featherrec_state"
        const val PREF_RECORDING = "recording"

        private const val TAG = "FeatherRec"
        private const val CHANNEL_ID = "featherrec_recording"
        private const val NOTIFICATION_ID = 6001
    }
}
