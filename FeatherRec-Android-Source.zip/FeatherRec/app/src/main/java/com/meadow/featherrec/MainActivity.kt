package com.meadow.featherrec

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 14, 19)
    private val panel = Color.rgb(21, 26, 36)
    private val muted = Color.rgb(157, 168, 184)
    private val mint = Color.rgb(114, 240, 187)
    private val red = Color.rgb(255, 105, 116)

    private lateinit var statusText: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var micCheck: CheckBox
    private lateinit var resolution720: Button
    private lateinit var resolutionNative: Button
    private var use720p = true
    private var receiverRegistered = false

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val active = intent?.getBooleanExtra(RecorderService.EXTRA_RUNNING, false) == true
            renderRecordState(active)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildUi()
        renderRecordState(getSharedPreferences(RecorderService.PREFS, MODE_PRIVATE)
            .getBoolean(RecorderService.PREF_RECORDING, false))
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            fillViewport = true
            setBackgroundColor(bg)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
        }
        scroll.addView(root, ViewGroup.LayoutParams(-1, -2))
        setContentView(scroll)

        val eyebrow = text("LIGHTWEIGHT SCREEN CAPTURE", 11, mint, true).apply {
            letterSpacing = 0.12f
        }
        root.addView(eyebrow)
        root.addView(space(9))
        root.addView(text("FeatherRec", 32, Color.WHITE, true))
        root.addView(space(5))
        root.addView(text("Smooth clips. Less overhead.", 15, muted, false))
        root.addView(space(24))

        val statusCard = panelCard()
        statusCard.orientation = LinearLayout.HORIZONTAL
        statusCard.gravity = Gravity.CENTER_VERTICAL
        val statusDot = TextView(this).apply {
            text = "●"
            textSize = 15f
            setTextColor(mint)
        }
        statusCard.addView(statusDot)
        statusCard.addView(spaceWidth(10))
        val statusColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        statusColumn.addView(text("RECORDER STATUS", 10, muted, true))
        statusText = text("Ready to record", 15, Color.WHITE, true)
        statusColumn.addView(statusText)
        statusCard.addView(statusColumn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(statusCard, fullWidth())
        root.addView(space(18))

        val settings = panelCard()
        settings.orientation = LinearLayout.VERTICAL
        settings.addView(text("CAPTURE SETTINGS", 11, muted, true))
        settings.addView(space(14))
        settings.addView(text("Resolution", 15, Color.WHITE, true))
        settings.addView(space(9))

        val resolutionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        resolution720 = Button(this).apply {
            text = "720p · recommended"
            isAllCaps = false
            textSize = 12f
            setPadding(dp(4), dp(7), dp(4), dp(7))
            setOnClickListener { use720p = true; updateResolutionStyles() }
        }
        resolutionNative = Button(this).apply {
            text = "Native"
            isAllCaps = false
            textSize = 12f
            setPadding(dp(4), dp(7), dp(4), dp(7))
            setOnClickListener { use720p = false; updateResolutionStyles() }
        }
        resolutionRow.addView(resolution720, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            marginEnd = dp(6)
        })
        resolutionRow.addView(resolutionNative, LinearLayout.LayoutParams(0, dp(48), 0.65f))
        settings.addView(resolutionRow, fullWidth())
        settings.addView(space(13))

        micCheck = CheckBox(this).apply {
            text = "Record microphone"
            textSize = 14f
            setTextColor(Color.WHITE)
            buttonTintList = android.content.res.ColorStateList.valueOf(mint)
            isChecked = false
        }
        settings.addView(micCheck)
        settings.addView(space(8))
        settings.addView(text("60 FPS target · MP4 · saved to Movies/FeatherRec", 12, muted, false))
        settings.addView(space(4))
        settings.addView(text("Mic audio only; internal game audio is not captured.", 12, muted, false))
        root.addView(settings, fullWidth())
        root.addView(space(22))

        startButton = Button(this).apply {
            text = "●   START RECORDING"
            isAllCaps = false
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(bg)
            background = rounded(mint, 16)
            setOnClickListener { onStartPressed() }
        }
        root.addView(startButton, LinearLayout.LayoutParams(-1, dp(58)))

        stopButton = Button(this).apply {
            text = "■   STOP & SAVE"
            isAllCaps = false
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(92, 31, 41), 16)
            visibility = View.GONE
            setOnClickListener { stopRecording() }
        }
        root.addView(stopButton, LinearLayout.LayoutParams(-1, dp(58)))
        root.addView(space(15))
        root.addView(text("TIP", 10, mint, true))
        root.addView(space(4))
        root.addView(text(
            "For landscape games, rotate your phone to landscape before you start. Then leave FeatherRec and open your game. Keep auto-rotate enabled if you need to switch orientation.",
            12, muted, false
        ))
        root.addView(space(14))
        root.addView(text("Your screen is captured only after you approve Android’s system prompt.", 11, muted, false))
        updateResolutionStyles()
    }

    private fun onStartPressed() {
        if (micCheck.isChecked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
            return
        }
        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Uses the activity result API supported by the minimum Android version.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, RecorderService::class.java).apply {
                    putExtra(RecorderService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(RecorderService.EXTRA_RESULT_DATA, data)
                    putExtra(RecorderService.EXTRA_720P, use720p)
                    putExtra(RecorderService.EXTRA_MIC, micCheck.isChecked)
                }
                startForegroundService(service)
                statusText.text = "Starting capture…"
            } else {
                Toast.makeText(this, "Screen capture cancelled", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @Deprecated("Permission callback for the minimum Android version.")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MIC) {
            if (grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
                micCheck.isChecked = false
                Toast.makeText(this, "Microphone off; starting video-only capture", Toast.LENGTH_LONG).show()
            }
            requestScreenCapture()
        }
    }

    private fun stopRecording() {
        startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
    }

    override fun onResume() {
        super.onResume()
        if (!receiverRegistered) {
            val filter = IntentFilter(RecorderService.ACTION_STATE)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(stateReceiver, filter)
            }
            receiverRegistered = true
        }
        renderRecordState(getSharedPreferences(RecorderService.PREFS, MODE_PRIVATE)
            .getBoolean(RecorderService.PREF_RECORDING, false))
    }

    override fun onPause() {
        if (receiverRegistered) {
            unregisterReceiver(stateReceiver)
            receiverRegistered = false
        }
        super.onPause()
    }

    private fun renderRecordState(active: Boolean) {
        if (!::statusText.isInitialized || !::startButton.isInitialized || !::stopButton.isInitialized) return
        statusText.text = if (active) "Recording at 60 FPS target" else "Ready to record"
        startButton.visibility = if (active) View.GONE else View.VISIBLE
        stopButton.visibility = if (active) View.VISIBLE else View.GONE
    }

    private fun updateResolutionStyles() {
        if (!::resolution720.isInitialized) return
        resolution720.background = rounded(if (use720p) mint else Color.rgb(33, 40, 52), 12)
        resolution720.setTextColor(if (use720p) bg else Color.WHITE)
        resolutionNative.background = rounded(if (!use720p) mint else Color.rgb(33, 40, 52), 12)
        resolutionNative.setTextColor(if (!use720p) bg else Color.WHITE)
    }

    private fun panelCard() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(17), dp(17), dp(17), dp(17))
        background = rounded(panel, 20).also {
            it.setStroke(dp(1), Color.rgb(39, 46, 60))
        }
    }

    private fun text(value: String, sizeSp: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = sizeSp.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = true
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun space(heightDp: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(heightDp))
    }

    private fun spaceWidth(widthDp: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(widthDp), 1)
    }

    private fun fullWidth() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        private const val REQUEST_CAPTURE = 301
        private const val REQUEST_MIC = 302
    }
}
