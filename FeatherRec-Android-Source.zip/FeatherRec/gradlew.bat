@echo off
setlocal
set GRADLE_VERSION=8.9
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set DIST_HOME=%GRADLE_USER_HOME%\wrapper\dists\gradle-%GRADLE_VERSION%-bin\manual
set GRADLE_BIN=%DIST_HOME%\gradle-%GRADLE_VERSION%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  if not exist "%DIST_HOME%" mkdir "%DIST_HOME%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%DIST_HOME%\gradle.zip'; Expand-Archive -Force '%DIST_HOME%\gradle.zip' '%DIST_HOME%'; Remove-Item '%DIST_HOME%\gradle.zip'"
  if not exist "%GRADLE_BIN%" exit /b 1
)
call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
