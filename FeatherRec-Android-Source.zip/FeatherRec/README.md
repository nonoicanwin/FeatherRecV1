# FeatherRec — lightweight Android screen recorder

FeatherRec is a small native Android screen recorder using Android MediaProjection and H.264/MP4 encoding. It targets Android 10+ (API 29), including a Samsung Galaxy M20 running Android 10.

## Intended settings

- 720p-class output by default to reduce encoding load and file size.
- Requests a 60 FPS encoder target (actual FPS depends on the phone's hardware encoder, thermal state, and game workload).
- Optional microphone audio, off by default. Android screen capture does not capture protected content, and this app records microphone audio only—not internal game audio.
- Saves clips to `Movies/FeatherRec`.
- Includes a foreground notification with a Stop action.
- Android's own capture-consent prompt is shown before every recording session.

## Build an APK in GitHub Actions

This source contains `.github/workflows/build-apk.yml`, which builds a debug APK using a cloud runner and uploads it as an Actions artifact.

1. Create a GitHub repository and upload the *contents* of this project folder (`FeatherRec`), so `.github/workflows/build-apk.yml` is at the repository path `.github/workflows/build-apk.yml` and `app/` is at the repository root.
2. Open the repository's **Actions** tab and select **Build FeatherRec APK**.
3. Click **Run workflow** (or push a commit to the default branch to trigger the build).
4. Open the completed workflow run and download the **FeatherRec-debug-APK** artifact. Extract the ZIP to get `app-debug.apk`.
5. On the phone, tap the APK to install. If Android asks, allow installation from that browser/file manager.

The APK is a debug build and is suitable for personal testing; this is not a Play Store release.

## Use

1. Enable auto-rotate and rotate the phone to the orientation you intend to capture; for landscape games, rotate to landscape first.
2. Select 720p for lower load or Native for full display dimensions.
3. Tap **Start Recording**, approve Android's screen-capture prompt, then switch to the game.
4. Stop from the notification or return to FeatherRec and tap **Stop & Save**.

## Notes

- 60 FPS is a requested target, not a guarantee. On the Galaxy M20, 720p is the recommended starting point; demanding games may still reduce actual frame rate or responsiveness.
- Start recording in the same orientation you plan to use. Changing orientation mid-recording may distort or letterbox the capture.
- Minimum Android version: Android 10 (API 29).
